int g;
int a;

int main (int args){
	int b;
	if(b>(a=3)){
	a=3*5;
	}else{}
	FUNCTION("popo",b," ",a,endl);
	return 0;
	//void function ();
	while(3>2){;}
	}
	
void function(int a, int[5] b){}
