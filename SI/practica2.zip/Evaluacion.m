function [C] = Evaluacion(M, A)
    %for i=1:m
    C = M(A(1), 1) + M(A(2), 2) + M(A(3), 3) + M(A(4), 4);
end