function [A, M] = Tareas()
    A = [1 2 3 4];
    M = [12 43 15 7; 9 10 6 4; 5 13 29 2; 4 11 17 9];
end
